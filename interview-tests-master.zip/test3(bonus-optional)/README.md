## Test-3 (Bonus Optional)
### Congrats, If you've made it till here. This test is optional and it's up to your creativity on how you go about attempting it
 - You must build a click counter using any popular framework (Angular is preferred). It has just one job: keep track of how many times the user has clicked the button during the current session. No storage. No network I/O. Just count clicks.