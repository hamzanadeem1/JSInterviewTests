'use strict';
const locations = require('./locations.interface');

class Test {
	constructor() {
		//displayLocations(); // You can comment this if you want
	}
}




  
 
let keys= Object.keys(locations.branch_timings);
let i=0;
while(i < keys.length)
{
    let key=keys[i];
    locations.branch_timings[key].timingsEnabled=false;
    i++;
}

console.log(locations);




// Do not edit below this line
const test = new Test();
