## Test-2 Part One
### If you've completed test-1, then get ready for another challenge
You can see there's a location object being printed, you must do the following
1. Make a copy of the locations object and in it, convert the values of all the `timingsEnabled` object to false.
2. When you've done part 1, make sure that nothing is changed in the original locations object.
Note:

- Do Not use `for-loops` nor `forEach`.
- It's encouraged that you divide your code into **pure** functions.
- The way you format your overall code will be closely analyzed.

## Test-2 Part Two, instructions are in the file partTwo.js