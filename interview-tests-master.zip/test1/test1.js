'use strict';
const products = require('./products.interface');
const cart = require('./cart.interface');

class Test {
	constructor() {
		leastPriceWithThisName();
	}
}

const displayProducts = () => {
	console.log('products', products);
}

const displayCart = () => {
	console.log('cart', cart);
}
var i=0;
var productNamePrice=[];

while( i<products.length )
{
	productNamePrice=products[i].productName;
	console.log('Name:',productNamePrice); 			//task 1
	productNamePrice=products[i].productPrice;
	console.log('Price:',productNamePrice);
	i++;
}

var i=0;
var sum=0;
var b=0;

while(i<cart.length)
	{
		b=cart[i].quantity
		sum=sum+b;
		i++;                 //task 3
	}
	console.log('The total quantity of items in the cart array is', sum);


	cart.sort(function(a, b) {
		return a.basePrice - b.basePrice; //task 4
	 })
	 console.log(cart[0])  //min
	 console.log(cart[cart.length - 1]) //max




var i=0;
var sum=0;
var b=0;

while(i<cart.length)
	{
		b=cart[i].price
		sum=sum+b; //to find the total first
		i++; 
	}

var j=0;
while(j<cart.length)
{
	if(cart[j].discountedPrice>=0) //task 5
	{
	var d=0;
	d=cart[j].discountedPrice; //running iterations to deduct discount
	sum=sum-d;
	j++;
	}
}

console.log('total price of cart including discounts: ', sum);


var pPrice=[];
var i=0;
var j=0;
while(i<products.length){

	if(products[i].productName=="Stamps and Flower - Sage")
	{
		pPrice[j]=products[i].productPrice;
		j++;
	}
	i++;
	

}

console.log(pPrice);
console.log(Math.min.apply(Math,pPrice)); //task 2


const leastPriceWithThisName= () =>{
}


// Do not edit below this line
const test = new Test();
